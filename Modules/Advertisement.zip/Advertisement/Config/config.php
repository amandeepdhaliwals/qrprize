<?php

return [
    'name' => 'Advertisement',
];
