<?php

namespace Modules\Advertisement\Http\Controllers\Backend;

use App\Authorizable;
use App\Http\Controllers\Backend\BackendBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class AdvertisementController extends BackendBaseController
{
    use Authorizable;

    public function __construct()
    {
        // Page Title
        $this->module_title = 'Advertisement';

        // Module name
        $this->module_name = 'advertisement';

        // Directory path of the module
        $this->module_path = 'advertisement::backend';

        // Module icon
        $this->module_icon = 'fa-regular fa-sun';

        // Module model name, path
        $this->module_model = "Modules\Advertisement\Entities\Advertisement";
    }
}
