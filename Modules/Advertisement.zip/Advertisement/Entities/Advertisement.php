<?php

namespace Modules\Advertisement\Entities;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Advertisement\Database\Factories\AdvertisementFactory;
use Illuminate\Support\Facades\DB;

class Advertisement extends BaseModel
{
    use HasFactory;

    protected $table = 'advertisements';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    protected static function newFactory(): AdvertisementFactory
    {
       // return AdvertisementFactory::new();
    }


}
