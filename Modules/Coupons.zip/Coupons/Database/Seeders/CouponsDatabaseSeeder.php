<?php

namespace Modules\Coupons\Database\Seeders;

use Illuminate\Database\Seeder;

class CouponsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
